---
name: arch-iso-builder
description: 'Build Arch Linux live ISOs with archiso. Handles profile configuration, package selection, boot modes (BIOS syslinux + UEFI systemd-boot), and ISO generation. The main orchestration skill for the group, driven by the design brief from arch-distro-design. Use when the user needs a bootable live ISO.'
---

# Arch ISO Builder — General Purpose

Skill for building Arch Linux live ISOs using `archiso 91-1`. It works for
**any** Arch-based distribution. It decides the profile structure, which
packages go in the live system versus the frozen repo, and runs `mkarchiso`.

## ⚠️ MANDATORY: prior Brief

> **Directive from `arch-distro-design`:** This skill must **NEVER** be invoked
> without first completing the design `Brief`.

| Category | What it defines for this skill |
|---|---|
| **Objective** | Whether it is a live ISO, a persistent .img, or both. |
| **Output format** | Determines whether we build an ISO, a .img, or both. |
| **Target hardware** | x86_64 UEFI, BIOS, USB disk, HDD, SSD, NVMe. |
| **Network** | 100% local, LAN DHCP, internet expected, or completely offline. |
| **Apps / Payloads** | Which applications are included, runtimes, DB. |
| **Immutability** | Root squashfs ro, rw with a rule, or overlay? |
| **Update policy** | How and when it updates. |

> **If the `Brief` is not complete, stop the invocation and ask for the 7
> mandatory categories.**

## When to use this skill

- The user wants to create an Arch live ISO for a specific purpose.
- `arch-distro-design` has already made the design decisions and passed them on.
- A valid archiso profile is needed (boot modes, variables, overlay).
- The profile must pass `mkarchiso --validate` before building.
- A custom `airootfs/` overlay must be injected.

## Produced artifacts

| Output | Description |
|---|---|
| `out/*.iso` | Bootable ISO (BIOS + UEFI) with a squashfs rootfs |
| `out/SHA256SUMS` | ISO checksums (for versioning) |
| `builder/arch-profile/` | Profile ready for `mkarchiso` |

## Mandatory workflow

### 1. Receive the `Brief` from `arch-distro-design`

`arch-distro-design` must have already defined the 7 categories.

### 2. Define the profile (`profiledef.sh`)

Critical variables that must **always** be declared:

```bash
iso_name="distro-name"
iso_label="LABEL"
iso_publisher="publisher"
iso_application="Description"
install_dir="arch"          # relative, max 30 chars [a-z0-9]
buildmodes=('iso')         # valid: bios.syslinux, uefi.systemd-boot
bootmodes=('bios.syslinux' 'uefi.systemd-boot') # ONLY these 3 in archiso 91-1
pacman_conf="pacman.conf"
packages="packages.x86_64"
bootstrap_packages="bootstrap_packages.x86_64" # MUST EXIST even if empty
airootfs_image_type="squashfs"
kernel_params="console=tty0 console=ttyS0,115200n8"
```

### 3. Package list (`packages.x86_64`)

| Category | Packages (examples — choose according to the Brief's objective) |
|---|---|
| **system base** | `base`, `linux`, `linux-firmware`, `grub`, `efibootmgr` |
| **mandatory archiso** | `mkinitcpio`, `mkinitcpio-archiso`, `syslinux` |
| **builder tools** | `e2fsprogs`, `dosfstools`, `parted`, `arch-install-scripts` |
| **access and maintenance** | `openssh`, `sudo`, `tmux`, `curl`, `rsync`, `wget`, `htop`, `nano`, `vim`, `less`, `usbutils`, `pciutils`, `nftables` |
| **window managers** (choose) | `openbox`, `i3`, `bspwm`, `awesome`, `herbstluftwm`, `jwm`, `fluxbox`, `windowmaker` |
| **file managers** (choose) | `pcmanfm-qt`, `thunar`, `nemo`, `caja`, `rox-filer`, `spacefm`, `ranger`, `nnn`, `lf` |
| **desktop environment** (optional) | `xorg-server`, `xorg-xinit`, `falkon`, `plasma-desktop`, `xfce4`, `gnome`, `mate-desktop` |
| **image viewer** | `feh`, `sxiv`, `imagemagick` |
| **text editor** | `vim`, `nano`, `neovim`, `leafpad`, `mousepad` |
| **NEVER in live** | `base-devel` (~1 GB unused), `calamares` (unless explicitly requested) |

> **⚠️ `community` was merged into `extra`** (2026-11-09). Never declare
> `[community]`: it breaks the build with a 404.

### 4. Profile `pacman.conf`

**⚠️ MANDATORY:** The build host must always be **Arch**. Do not use
`Include = /etc/pacman.d/mirrorlist` (the host may be Manjaro or another distro
and would contaminate the ISO with non-Arch packages).

```ini
[options]
HoldPkg = pacman glibc
Architecture = auto
SigLevel = Required DatabaseOptional
LocalFileSigLevel = Optional
ParallelDownloads = 5

[core]
Server = https://mirror.raiolanetworks.com/archlinux/$repo/os/$arch
Server = https://mirror.dkm.cz/archlinux/$repo/os/$arch
Server = https://mirror.rackspace.com/archlinux/$repo/os/$arch
Server = https://mirrors.dotsrc.org/archlinux/$repo/os/$arch
Server = https://mirror.garr.it/archlinux/$repo/os/$arch

[extra]
Server = https://mirror.raiolanetworks.com/archlinux/$repo/os/$arch
Server = https://mirror.dkm.cz/archlinux/$repo/os/$arch
Server = https://mirror.rackspace.com/archlinux/$repo/os/$arch
Server = https://mirrors.dotsrc.org/archlinux/$repo/os/$arch
Server = https://mirror.garr.it/archlinux/$repo/os/$arch

# 🔴 AUR repository — DO NOT INCLUDE BY DEFAULT.
# AUR packages are not signed by the Arch keyring. SigLevel=Optional
# disables signature verification. Only include it if the Brief explicitly
# authorizes it and the user accepts the risk in writing.
# [aur]
# SigLevel = Optional
# Server = file:///aur-repo
```

> **Minimum 5 servers per repo** (core and extra) to tolerate mirror failures.

> **XferCommand** (CLI flag, not a config directive): `--speed-time 120 --speed-limit 10`
> to tolerate intermittent mirrors.

### 5. `airootfs/` overlay

`mkarchiso` copies `airootfs/.` **with mode 644/755**, which is why
`file_permissions` in `profiledef.sh` is mandatory for executables.

| File | Reason |
|---|---|
| `etc/shadow` | live root password |
| `etc/pacman.conf` | override: `community` repo 404 → own config with `[appliance]` |
| `etc/mkinitcpio.conf.d/archiso.conf` | MANDATORY hooks: `base udev archiso archiso_loop_mnt memdisk microcode` |
| `etc/systemd/system/getty@tty1.service.d/autologin.conf` | tty1 autologin |
| `root/.bash_profile` | `startx` if `tty = /dev/tty1` |
| `root/.xinitrc` | `tint2 &` + `exec openbox-session` (or the WM chosen by the Brief) |
| `root/.xprofile` | Qt/X environment variables |

### 6. Valid boot modes (archiso 91-1)

| Boot mode | Boot | Requires |
|---|---|---|
| `bios.syslinux` | Legacy BIOS | `syslinux/` with `.cfg` |
| `uefi.systemd-boot` | UEFI systemd-boot | `efiboot/loader/loader.conf` + `.conf` |
| `uefi.grub` | UEFI with GRUB | `grub/` |

> The `.esp` / `.mbr` / `.eltorito` suffixes are **internal** to archiso and
> fail with `return 1`. Do not use them.

### 7. Calling `mkarchiso`

```bash
set -euo pipefail

mkdir -p /var/tmp/archiso-work "$PWD/out"
sudo mkarchiso -v -w /var/tmp/archiso-work -o "$PWD/out" "$PWD/builder/arch-profile"
```

Mandatory pre-checks:
- `work_dir` and `out_dir` exist (`mkdir -p`)
- `bootstrap_packages.x86_64` exists (even if empty)
- Paths are **relative to the profile** (archiso `cd`s into the profile)

### 8. Post-build

```bash
set -euo pipefail

# Work dir cleanup — guarded against empty paths
: "${WORKDIR:=/var/tmp/archiso-work}"
case "$WORKDIR" in
  /|""|/var/tmp|/tmp) echo "❌ Unsafe WORKDIR: $WORKDIR" >&2; exit 1 ;;
esac
rm -rf -- "$WORKDIR"

sha256sum out/*.iso > out/SHA256SUMS
```

## Pre-build validation

| Check | Command | Expected |
|---|---|---|
| Valid profile | `mkarchiso -v ... 2>&1 | head -10` | No ERROR, only INFO |
| No community | `grep -R 'community' builder/arch-profile/` | absent |
| Syslinux exists | `ls builder/arch-profile/syslinux/` | `.cfg` present |
| UEFI exists | `ls builder/arch-profile/efiboot/loader/` | `loader.conf` present |
| XferCommand ok | `grep XferCommand builder/arch-profile/pacman.conf` | has `curl` |

## Handoff to other skills in the group

| If you touch... | Go to |
|---|---|
| partitioning, .img, DATA | `arch-appliance-img` |
| local signed offline repo | `arch-frozen-repo` |
| KEY=VALUE manifest + runtime | `arch-payload-manifest` |
| desktop, panel, kiosk | `arch-desktop-layers` |
| tests, boot, shutdown | `arch-qemu-validation` |
| "this failed with..." | `arch-archlinux-pitfalls` |
| validate hardware before writing | `arch-hardware-handler` |

## Common errors

| Error | Cause | Prevention |
|---|---|---|
| `realpath: ''` | Empty variable in profiledef.sh | Relative paths + empty file created |
| `bootmode invalid` | `uefi.systemd-boot.esp` written by hand | Only the 3 documented names |
| `community.db` → **404** | `[community]` in pacman.conf | Remove it; use only core+extra |
| `DisableDownloadTimeout not recognized` | Config flag, not CLI | Use `XferCommand` with curl |
| `pacman --root` relocates `GPGDir` | Not true | Host keyring, empty target |
| `overlay` does not preserve permissions | `cp -af` without `--no-preserve` | `file_permissions` in profiledef.sh |
| Build without completing the Brief | Real objective not met | **MANDATORY**: Brief with 7 categories |
| `base-devel` in live unnecessarily | ~1 GB installed without use | Review the package list |
| `calamares` without an explicit request | Unrequested GUI installer | Do not include it unless the Brief asks for it |
